//import {Simulation} from "./simulation";
//export default Simulation;
//
//export {SimConfig, PeerConfig, ChannelConfig} from "./simulation-config";
export {SimConfig, PeerConfig, ChannelConfig} from "./simulation-config";
export {Simulation} from "./simulation";