export class ControlBits {
    public ack: boolean = false;
    public syn: boolean = false;
    public rst: boolean = false;
    public fin: boolean = false;

    constructor() {}
}