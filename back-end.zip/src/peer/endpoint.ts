export type Endpoint = {
    ip: string
    port: string
}