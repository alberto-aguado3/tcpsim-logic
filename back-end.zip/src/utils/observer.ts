export interface Observer {
    update(attribute: any): void
}
