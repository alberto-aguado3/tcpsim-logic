export type Log = {
    message: string;
    [key: string]: any
}